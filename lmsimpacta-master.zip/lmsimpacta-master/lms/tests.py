# Create your tests here.
def test_pytest_enabled():
    assert 1 == 1