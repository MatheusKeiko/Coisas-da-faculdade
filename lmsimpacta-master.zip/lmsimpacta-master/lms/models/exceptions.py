class MensagemSemMatriculaException(Exception):
    pass