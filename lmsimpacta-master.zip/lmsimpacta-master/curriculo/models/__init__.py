from .cursos import Curso
from .disciplinas import Disciplina
from .turmas import Turma
from .disciplinas_ofertadas import DisciplinaOfertada