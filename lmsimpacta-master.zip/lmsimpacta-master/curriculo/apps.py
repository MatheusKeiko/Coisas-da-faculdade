from django.apps import AppConfig


class CurriculoConfig(AppConfig):
    name = 'curriculo'
    verbose_name = 'Currículo'
