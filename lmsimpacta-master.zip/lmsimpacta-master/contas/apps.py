from django.apps import AppConfig


class ContasConfig(AppConfig):
    name = 'contas'
