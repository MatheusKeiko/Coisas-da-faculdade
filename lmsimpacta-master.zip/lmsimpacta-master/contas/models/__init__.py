from .pessoas import Pessoa
from .usuarios import Usuario
from .coordenadores import Coordenador
from .professores import Professor
from .alunos import Aluno
